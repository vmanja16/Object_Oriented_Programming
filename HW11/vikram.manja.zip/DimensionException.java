class DimensionException extends Exception{
	public DimensionException(String e){
		System.out.println("Error: dimension " + e + " is not valid!");
	}

	
}