interface MyList{

	abstract public MyList next();

	abstract public void printNode();
}