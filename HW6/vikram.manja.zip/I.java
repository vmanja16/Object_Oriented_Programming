interface I {

   //public I( ) { }; // A

   int s = 0;
   int i = 1;

   void foo(short s); 

   void foo(int i); 

}
